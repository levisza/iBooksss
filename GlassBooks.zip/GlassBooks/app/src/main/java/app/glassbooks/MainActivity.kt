package app.glassbooks

import android.content.Context
import android.os.Bundle
import android.text.Html
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLDecoder
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App() }
    }
}

val accent = Color(0xFFFF9F0A)

data class Book(val title: String, val author: String, val c1: Color, val c2: Color, val chapters: List<String>)
data class Note(val ch: Int, val text: String)

// ---------- EPUB ----------
fun attr(s: String, k: String) = Regex("\\b$k=\"([^\"]*)\"").find(s)?.groupValues?.get(1) ?: ""

fun plain(h: String) = Html.fromHtml(h, Html.FROM_HTML_MODE_LEGACY).toString()
    .replace("\uFFFC", "").replace(Regex("\n{3,}"), "\n\n").trim()

fun parseEpub(f: File): Book? = runCatching {
    val files = HashMap<String, String>()
    ZipInputStream(f.inputStream()).use { z ->
        var e = z.nextEntry
        while (e != null) {
            if (Regex(".*\\.(opf|xml|x?html?)$").matches(e.name)) files[e.name] = z.readBytes().toString(Charsets.UTF_8)
            e = z.nextEntry
        }
    }
    val opfPath = attr(files["META-INF/container.xml"]!!, "full-path")
    val opf = files[opfPath]!!
    val dir = opfPath.substringBeforeLast('/', "")
    val hrefs = Regex("<item\\s[^>]*>").findAll(opf).associate { attr(it.value, "id") to attr(it.value, "href") }
    val chapters = Regex("<itemref\\s[^>]*>").findAll(opf).mapNotNull { m ->
        val h = URLDecoder.decode(hrefs[attr(m.value, "idref")] ?: return@mapNotNull null, "UTF-8").substringBefore('#')
        val html = files[if (dir.isEmpty()) h else "$dir/$h"]
            ?: files.entries.firstOrNull { it.key.endsWith(h.substringAfterLast('/')) }?.value
        html?.replace(Regex("(?s)<head.*?</head>|<style.*?</style>"), "")?.let(::plain)
    }.filter { it.length > 60 }.toList()
    fun meta(t: String) = Regex("(?s)<dc:$t[^>]*>(.*?)</dc:$t>").find(opf)?.groupValues?.get(1)?.let(::plain)
    val title = meta("title") ?: f.nameWithoutExtension
    val hue = (title.hashCode() and 0x7fffffff) % 360f
    Book(title, meta("creator") ?: "", Color.hsv(hue, 0.6f, 0.75f), Color.hsv(hue, 0.7f, 0.3f), chapters)
}.getOrNull()?.takeIf { it.chapters.isNotEmpty() }

// ---------- Armazenamento (progresso e notas) ----------
fun prefs(c: Context, n: String) = c.getSharedPreferences(n, 0)

fun loadNotes(c: Context, k: String): List<Note> = runCatching {
    val a = JSONArray(prefs(c, "notes").getString(k, "[]"))
    List(a.length()) { Note(a.getJSONObject(it).getInt("c"), a.getJSONObject(it).getString("t")) }
}.getOrDefault(emptyList())

fun saveNotes(c: Context, k: String, l: List<Note>) {
    val a = JSONArray()
    l.forEach { a.put(JSONObject().put("c", it.ch).put("t", it.text)) }
    prefs(c, "notes").edit().putString(k, a.toString()).apply()
}

// ---------- Liquid glass ----------
fun Modifier.glass(hz: HazeState, shape: Shape, dark: Boolean): Modifier = this
    .shadow(18.dp, shape, ambientColor = Color.Black.copy(0.12f), spotColor = Color.Black.copy(0.18f))
    .clip(shape)
    .hazeEffect(hz) {
        blurRadius = 26.dp
        backgroundColor = if (dark) Color(0xFF1C1C1E) else Color(0xFFF2F2F7)
        tints = listOf(HazeTint(Color.White.copy(alpha = if (dark) 0.10f else 0.30f)))
        noiseFactor = 0.03f
    }
    .border(
        1.dp,
        Brush.linearGradient(listOf(Color.White.copy(0.85f), Color.White.copy(0.05f), Color.White.copy(0.45f))),
        shape
    )

@Composable
fun GlassButton(hz: HazeState, dark: Boolean, label: String, color: Color, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 1.15f else 1f, spring(0.45f, 500f), label = "press")
    Box(
        Modifier.graphicsLayer { scaleX = s; scaleY = s }
            .height(46.dp).widthIn(min = 46.dp)
            .glass(hz, CircleShape, dark)
            .clickable(src, null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, Modifier.padding(horizontal = 14.dp), color = color,
            fontSize = if (label.length > 1) 15.sp else 22.sp, fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun Field(v: String, on: (String) -> Unit, hint: String, fg: Color, m: Modifier = Modifier) {
    BasicTextField(
        v, on, m.clip(CircleShape).background(fg.copy(0.10f)).padding(16.dp, 12.dp),
        textStyle = TextStyle(color = fg, fontSize = 17.sp), singleLine = true,
        cursorBrush = SolidColor(accent),
        decorationBox = { inner ->
            Box {
                if (v.isEmpty()) Text(hint, color = fg.copy(0.4f), fontSize = 17.sp)
                inner()
            }
        }
    )
}

// ---------- Telas ----------
@Composable
fun App() {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val books = remember { mutableStateListOf<Book>() }
    var open by remember { mutableStateOf<Book?>(null) }
    val scope = rememberCoroutineScope()
    val dir = remember { File(ctx.filesDir, "books").apply { mkdirs() } }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            dir.listFiles()?.sortedBy { it.name }?.mapNotNull(::parseEpub)?.let { books.addAll(it) }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            val f = File(dir, "${System.currentTimeMillis()}.epub")
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }
            parseEpub(f)?.let { books.add(it) } ?: f.delete()
        }
    }
    val b = open
    if (b == null) Library(books, dark, { picker.launch(arrayOf("application/epub+zip")) }) { open = it }
    else Reader(b, dark) { open = null }
}

@Composable
fun Library(books: List<Book>, dark: Boolean, onImport: () -> Unit, onOpen: (Book) -> Unit) {
    val ctx = LocalContext.current
    val hz = remember { HazeState() }
    var tab by remember { mutableIntStateOf(1) }
    val fg = if (dark) Color.White else Color.Black
    fun prog(b: Book) = prefs(ctx, "pos").getInt(b.title, 0).toFloat() / b.chapters.size
    val list = if (tab == 0) books.filter { prog(it) > 0 } else books
    Box(Modifier.fillMaxSize().background(if (dark) Color.Black else Color(0xFFF2F2F7))) {
        LazyVerticalGrid(
            GridCells.Fixed(2),
            Modifier.fillMaxSize().hazeSource(hz),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 120.dp)
        ) {
            item(span = { GridItemSpan(2) }) {
                Text(
                    if (tab == 0) "Lendo agora" else "Biblioteca",
                    Modifier.statusBarsPadding().padding(8.dp, 24.dp, 8.dp, 8.dp),
                    color = fg, fontSize = 34.sp, fontWeight = FontWeight.Bold
                )
            }
            if (list.isEmpty()) item(span = { GridItemSpan(2) }) {
                Text("Toque em + para importar um arquivo EPUB.", Modifier.padding(24.dp), color = fg.copy(0.5f))
            }
            items(list) { b -> Cover(b, fg, prog(b)) { onOpen(b) } }
        }
        Box(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(end = 16.dp, top = 20.dp)) {
            GlassButton(hz, dark, "+", accent, onImport)
        }
        Row(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp)
                .glass(hz, CircleShape, dark).padding(5.dp)
        ) {
            listOf("Lendo agora", "Biblioteca").forEachIndexed { i, t ->
                val sel = tab == i
                Text(
                    t,
                    Modifier.clip(CircleShape)
                        .background(if (sel) fg.copy(0.10f) else Color.Transparent)
                        .clickable { tab = i }
                        .padding(22.dp, 12.dp),
                    color = if (sel) accent else fg.copy(0.7f),
                    fontWeight = FontWeight.SemiBold, fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
fun Cover(b: Book, fg: Color, p: Float, onClick: () -> Unit) {
    Column(Modifier.padding(8.dp).clickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.68f)
                .shadow(10.dp, RoundedCornerShape(6.dp)).clip(RoundedCornerShape(6.dp))
                .background(Brush.linearGradient(listOf(b.c1, b.c2))).padding(14.dp)
        ) {
            Text(b.title, color = Color.White, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 4)
            Text(b.author, Modifier.align(Alignment.BottomStart), color = Color.White.copy(0.8f), fontSize = 11.sp, maxLines = 1)
        }
        Text(
            if (p > 0) "${(p * 100).toInt()}%" else "Novo",
            Modifier.padding(top = 6.dp), color = fg.copy(0.5f), fontSize = 12.sp
        )
    }
}

@Composable
fun Reader(book: Book, dark: Boolean, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val hz = remember { HazeState() }
    val scroll = rememberScrollState()
    var ch by remember { mutableIntStateOf(prefs(ctx, "pos").getInt(book.title, 0).coerceIn(0, book.chapters.lastIndex)) }
    var theme by remember { mutableIntStateOf(if (dark) 2 else 0) }
    var size by remember { mutableFloatStateOf(19f) }
    var chrome by remember { mutableStateOf(true) }
    var mode by remember { mutableIntStateOf(0) } // 0 leitura, 1 busca, 2 notas
    var query by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    val notes = remember { mutableStateListOf<Note>().apply { addAll(loadNotes(ctx, book.title)) } }
    val (bg, fg) = listOf(
        Color.White to Color(0xFF1C1C1E),
        Color(0xFFF4ECD8) to Color(0xFF5B4636),
        Color(0xFF1C1C1E) to Color(0xFFE5E5E7)
    )[theme]
    val d = theme == 2
    val pct = if (scroll.maxValue > 0) scroll.value * 100 / scroll.maxValue else 0
    val hits = remember(query) {
        if (query.length < 2) emptyList() else {
            val re = Regex(Regex.escape(query), RegexOption.IGNORE_CASE)
            book.chapters.withIndex().flatMap { (i, t) -> re.findAll(t).take(5).map { i to it.range.first }.toList() }.take(40)
        }
    }
    LaunchedEffect(ch) {
        scroll.scrollTo(0)
        prefs(ctx, "pos").edit().putInt(book.title, ch).apply()
    }
    fun save() = saveNotes(ctx, book.title, notes.toList())

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().hazeSource(hz).background(bg)
                .pointerInput(Unit) { detectTapGestures { if (mode != 0) mode = 0 else chrome = !chrome } }
                .verticalScroll(scroll).padding(horizontal = 26.dp)
        ) {
            Spacer(Modifier.statusBarsPadding().height(90.dp))
            Text(book.chapters[ch], color = fg, fontFamily = FontFamily.Serif, fontSize = size.sp, lineHeight = (size * 1.6f).sp)
            Spacer(Modifier.navigationBarsPadding().height(190.dp))
        }
        AnimatedVisibility(chrome || mode != 0, Modifier.align(Alignment.TopCenter), enter = fadeIn(), exit = fadeOut()) {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp), Arrangement.SpaceBetween) {
                GlassButton(hz, d, "‹", fg, onBack)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton(hz, d, "Notas", if (mode == 2) accent else fg) { mode = if (mode == 2) 0 else 2 }
                    GlassButton(hz, d, "Buscar", if (mode == 1) accent else fg) { mode = if (mode == 1) 0 else 1 }
                }
            }
        }
        if (mode != 0) Column(
            Modifier.align(Alignment.TopCenter).statusBarsPadding()
                .padding(start = 14.dp, end = 14.dp, top = 74.dp)
                .fillMaxWidth().fillMaxHeight(0.6f)
                .glass(hz, RoundedCornerShape(30.dp), d).padding(18.dp)
        ) {
            if (mode == 1) {
                Field(query, { query = it }, "Buscar no livro", fg, Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                LazyColumn {
                    items(hits) { (i, p) ->
                        val t = book.chapters[i]
                        val e = p + query.length
                        Column(Modifier.fillMaxWidth().clickable { ch = i; mode = 0 }.padding(vertical = 10.dp)) {
                            Text("Capítulo ${i + 1}", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(
                                buildAnnotatedString {
                                    append("…" + t.substring((p - 30).coerceAtLeast(0), p).replace('\n', ' '))
                                    withStyle(SpanStyle(color = accent, fontWeight = FontWeight.Bold)) { append(t.substring(p, e)) }
                                    append(t.substring(e, (e + 40).coerceAtMost(t.length)).replace('\n', ' ') + "…")
                                },
                                color = fg, fontSize = 15.sp
                            )
                        }
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Field(draft, { draft = it }, "Nota no capítulo ${ch + 1}", fg, Modifier.weight(1f))
                    Text(
                        "Salvar",
                        Modifier.padding(start = 8.dp).clip(CircleShape).background(accent).clickable {
                            if (draft.isNotBlank()) { notes.add(0, Note(ch, draft.trim())); draft = ""; save() }
                        }.padding(16.dp, 12.dp),
                        color = Color.White, fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(Modifier.height(10.dp))
                LazyColumn {
                    itemsIndexed(notes) { i, n ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable { ch = n.ch; mode = 0 }) {
                                Text("Capítulo ${n.ch + 1}", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(n.text, color = fg, fontSize = 15.sp)
                            }
                            Text("×", Modifier.clickable { notes.removeAt(i); save() }.padding(10.dp), color = fg.copy(0.5f), fontSize = 22.sp)
                        }
                    }
                }
            }
        }
        AnimatedVisibility(chrome && mode == 0, Modifier.align(Alignment.BottomCenter), enter = fadeIn(), exit = fadeOut()) {
            Column(
                Modifier.navigationBarsPadding().padding(14.dp).fillMaxWidth()
                    .glass(hz, RoundedCornerShape(30.dp), d).padding(18.dp)
            ) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text("‹", Modifier.clickable { if (ch > 0) ch-- }.padding(horizontal = 14.dp), color = fg, fontSize = 28.sp)
                    Text("Capítulo ${ch + 1} de ${book.chapters.size} · $pct%", color = fg.copy(0.7f), fontSize = 13.sp)
                    Text("›", Modifier.clickable { if (ch < book.chapters.lastIndex) ch++ }.padding(horizontal = 14.dp), color = fg, fontSize = 28.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("A", color = fg, fontSize = 13.sp)
                    Slider(
                        size, { size = it }, Modifier.weight(1f).padding(horizontal = 8.dp),
                        valueRange = 14f..30f,
                        colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
                    )
                    Text("A", color = fg, fontSize = 24.sp)
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.SpaceEvenly) {
                    listOf(Color.White, Color(0xFFF4ECD8), Color(0xFF1C1C1E)).forEachIndexed { i, c ->
                        Box(
                            Modifier.size(38.dp).clip(CircleShape).background(c)
                                .border(
                                    if (theme == i) 3.dp else 1.dp,
                                    if (theme == i) accent else Color.Gray.copy(0.5f),
                                    CircleShape
                                )
                                .clickable { theme = i }
                        )
                    }
                }
            }
        }
    }
}
